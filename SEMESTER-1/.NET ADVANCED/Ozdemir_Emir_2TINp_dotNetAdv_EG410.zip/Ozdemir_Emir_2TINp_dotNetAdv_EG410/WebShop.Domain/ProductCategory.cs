﻿namespace WebShop.Domain
{
    public class ProductCategory
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}