package be.pxl.ja.opgave2;

public class CrashException extends RuntimeException{
        public CrashException(String message) {
            super(message);
        }
}
