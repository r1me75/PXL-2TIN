package be.pxl.ja.opgave2;

public interface Race<T> {

	double getDistance();
	void finish(T racer);
}
