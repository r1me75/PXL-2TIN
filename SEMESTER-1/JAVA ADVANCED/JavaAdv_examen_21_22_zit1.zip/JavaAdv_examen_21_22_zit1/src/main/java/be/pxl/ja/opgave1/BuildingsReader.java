package be.pxl.ja.opgave1;

public class BuildingsReader {

}
