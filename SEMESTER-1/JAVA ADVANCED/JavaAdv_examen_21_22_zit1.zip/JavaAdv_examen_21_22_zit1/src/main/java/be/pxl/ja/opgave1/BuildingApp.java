package be.pxl.ja.opgave1;

import java.util.List;

public class BuildingApp {

	private List<Building> buildings;

	public BuildingApp() {
		// TODO: read data from file buildings.csv and assign to buildings
	}

	// 1. Geef het aantal buildings van vóór het jaar 1970 (1970 excl.)
	public long solution1() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 2. Geef de naam van de hoogste building
	public String solution2() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 3. Hoeveel van de buildings worden gebruikt als hotel?
	public long solution3() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 4. Geef een tekst met de verschillende landen: geen dubbels, alfabetisch gesorteerd en gescheiden met een komma.
	public String solution4() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 5. Geef een lijst van alle buildings met type SKYSCRAPER van het jaar 2000. Sorteer de buildings alfabetisch (A -> Z) op city.
	public List<Building> solution5() {
		// TODO
		throw new UnsupportedOperationException();
	}
}
