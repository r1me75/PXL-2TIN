package be.pxl.ja.opgave1;

public interface LocationMapper {

	Location mapLocation(String city, String country, String lat, String lon);
}
