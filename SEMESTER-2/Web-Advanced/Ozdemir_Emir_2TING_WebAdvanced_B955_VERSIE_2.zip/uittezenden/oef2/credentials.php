<?php
$user = 'root';
$password = '';
$database = 'examen22';
$server = '127.0.0.1';

