import Course from '../../../src/js/school/Course';
import Student from '../../../src/js/school/Student';
// naam: 


