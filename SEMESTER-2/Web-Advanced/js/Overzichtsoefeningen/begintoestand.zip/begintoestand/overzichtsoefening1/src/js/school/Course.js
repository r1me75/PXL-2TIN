"use strict";
// naam: 
export default class Course {

}
