"use strict";
import Course from './Course';
// naam: 
export default class Student{

}
