"use strict";
// naam:
import Product from './Product';
export default class Container{

}
