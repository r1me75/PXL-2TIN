"use strict";
// naam
export default class Product{

}
