import Game from '../../../src/js/lingo/Game';
import Word from '../../../src/js/lingo/Word';
// naam:
