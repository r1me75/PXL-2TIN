"use strict";
// naam: 

export default class Word {

    evaluate(guessWord){
    }

}
