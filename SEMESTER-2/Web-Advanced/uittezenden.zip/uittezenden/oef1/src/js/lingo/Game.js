"use strict";
// naam: 
import Word from './Word';

export default class Game{

    addGuess(word){

    }

    get numberOfGuesses(){

    }

    evaluate(index){

    }

}


