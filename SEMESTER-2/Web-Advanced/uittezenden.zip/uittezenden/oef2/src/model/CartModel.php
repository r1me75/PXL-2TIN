<?php
// naam:
namespace model;

class CartModel {

    private $pdo;

    public function __construct(PDO $pdo){
        $this->pdo=$pdo;
    }

    public function getIds():array{
        // SELECT id FROM cart
        // maak een array met daarin alle id's uit de tabel cart
        // en geef deze array terug
    }

    public function getCart(int $id):Cart{
        // onderstaande query geeft 
        // een array terug met daarin een waarde voor quantity, name & price
        // van elk item in de cart met id = 1
        // pas aan zodanig dat id $id gebruikt wordt
        // als er geen waarden opgevraagd worden, wordt een Exception opgeworpen
        // anders wordt een Cart-object gemaakt met daarin alle CartItems 
        /*
        SELECT
            cart_items.quantity,
            product.name,
            product.price
        FROM cart
        JOIN cart_items
          ON cart.id = cart_items.cart_id
        JOIN product
          ON product.id = cart_items.product_id
        WHERE cart.id = 1
        */
         
    }
}

