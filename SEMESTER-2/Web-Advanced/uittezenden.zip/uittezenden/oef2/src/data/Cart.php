<?php 
// naam:
namespace data;
class Cart {

    private $cartItems;

    public function __construct(){
        // maak van de eigenschap $cartItems een lege arry
    }

    public function addCartItem(CartItem $cartItem){
        // voeg $cartItem toe aan de eigenschap $cartItems

    }

    public function getNumberOfCartItems():int{
        // geef het aantal waarden in de eigenschap $cartItems
    }

    public function getCartItem(int $i):CartItem{
        // de i'e waarde uit de eigenschap $cartItems terug
    }
}

