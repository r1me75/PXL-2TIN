<?php
$user = 'root';
$password = 'root';
$database = 'examen22';
$server = '192.168.33.22';

