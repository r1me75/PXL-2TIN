<?php
require_once 'credentials.php';
require_once 'vendor/autoload.php';


$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];

try{
    $pdo = new PDO("mysql:host=$server;dbname=$database", $user, $password, $options);
    // maak gebruik van CartModel om de id's van de tabel cart op te vragen 
    // en af te drukken in een select
} catch (Exception $exception){
    print("Something went wrong");
}




