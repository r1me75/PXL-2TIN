﻿using System;
using Microsoft.AspNetCore.Identity;

namespace ChatBot.Domain
{
    public class User : IdentityUser<Guid>
    {
        
    }
}