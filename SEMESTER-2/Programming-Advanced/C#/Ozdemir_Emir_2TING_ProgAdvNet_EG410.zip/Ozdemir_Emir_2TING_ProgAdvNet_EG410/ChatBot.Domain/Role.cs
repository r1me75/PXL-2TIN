﻿using System;
using Microsoft.AspNetCore.Identity;

namespace ChatBot.Domain
{
    public class Role : IdentityRole<Guid>
    {

    }
}