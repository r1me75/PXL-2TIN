﻿namespace ChatBot.AppLogic
{
    public interface IAnswerGenerator
    {
        string Answer(string question);
    }
}