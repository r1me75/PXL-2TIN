﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("ChatBot.Web")]
