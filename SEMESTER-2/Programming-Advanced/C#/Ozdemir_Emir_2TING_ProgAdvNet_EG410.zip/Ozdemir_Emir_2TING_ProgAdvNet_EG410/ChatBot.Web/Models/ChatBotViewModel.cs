namespace ChatBot.Web.Models
{
    public class ChatBotViewModel
    {
        public string BotName { get; set; }
        public string WelcomeMessage { get; set; }
    }
}