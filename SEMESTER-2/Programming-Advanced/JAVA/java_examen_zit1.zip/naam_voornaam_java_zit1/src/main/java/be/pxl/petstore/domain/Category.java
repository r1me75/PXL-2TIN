package be.pxl.petstore.domain;

public enum Category {
	FISH,
	DOGS,
	REPTILES,
	CATS,
	BIRDS;
}
